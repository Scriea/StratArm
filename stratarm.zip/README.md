# StratArm
Optimizing Trading Strategies via Multi-Armed Bandits
